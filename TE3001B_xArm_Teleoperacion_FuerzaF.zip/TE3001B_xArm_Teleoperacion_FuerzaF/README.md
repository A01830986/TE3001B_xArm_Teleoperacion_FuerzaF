# Teleoperación Bilateral con xArm Lite 6 - Prevención Exteroceptiva

Este repositorio contiene el código fuente para el sistema de teleoperación maestro-esclavo implementado en el Tecnológico de Monterrey.

## 📌 Aclaración sobre la Rúbrica y Archivos Entregados
Como se detalla extensamente en el reporte (Secciones IV y V), nuestro equipo optó por sustituir la inestable estimación por torque articular (`force_estimator.py`) por una **arquitectura de sensado exteroceptivo preventivo** operada mediante un radar ultrasónico y una placa STM32. 
Por lo tanto, la estimación de fuerza está embebida en la lógica discreta de `slave_control.py` y el hardware externo, garantizando un impacto de 0 N.

## 📂 Contenido del Directorio
* `reporte.pdf` / `reporte.tex`: Documento IEEE con la justificación matemática y experimental.
* `master_control.py`: Script para el xArm Maestro (envío de coordenadas y Muro Virtual).
* `slave_control.py`: Script para el xArm Esclavo (recepción, seguimiento ServoJ y lectura de STM32).
* `net_test.py`: Script de documentación sobre la validación de latencia de red.
* `data/`: Carpeta con registros de los ensayos experimentales.
* `figures/`: Recursos gráficos del artículo.
* `video_demo.mp4`: Demostración física del Muro Virtual en acción.

## 🚀 Instrucciones de Configuración y Ejecución

### 1. Preparación del Hardware y Red
1. **Conexión de los brazos:** Conectar el xArm Maestro a la PC Maestro y el xArm Esclavo a la PC Esclavo utilizando cables Ethernet directos.
2. **Configuración de IP:** Configurar manualmente los adaptadores de red de ambas computadoras para que estén en la misma subred que su respectivo brazo robótico.
3. **Conexión del sensor:** Conectar la placa STM32 (con el sensor ultrasónico) a un puerto USB de la PC Esclavo y verificar el número de puerto COM asignado.

### 2. Secuencia de Ejecución
1. Abrir una terminal en la **PC Esclavo** y ejecutar el script: `python slave_control.py`
2. Abrir una terminal en la **PC Maestro** y ejecutar el script: `python master_control.py`
3. En la terminal de la **PC Esclavo**, el sistema pausará y solicitará una confirmación de seguridad. Escribir que todo está correcto (ej. ingresando "si") para iniciar la rutina de calibración (*Homing*).
4. Una vez que ambos robots se alinien en su posición inicial cero, la teleoperación a 50 Hz comenzará.
5. **Prueba Háptica:** Mover el brazo Maestro libremente. Al acercar un objeto a menos de 10 cm del sensor en el Esclavo, el Maestro pasará automáticamente a Modo 0 (bloqueo rígido).
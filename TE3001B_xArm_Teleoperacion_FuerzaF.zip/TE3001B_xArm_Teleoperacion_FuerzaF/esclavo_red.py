import time
import socket
import json
import serial
from xarm.wrapper import XArmAPI

# --- CONFIGURACIÓN ---
IP_ROBOT_ESCLAVO = '192.168.1.154'
PUERTO_UDP_RECIBO = 9000
PUERTO_UDP_ENVIO = 9001  

PUERTO_STM32 = 'COM5'     # <--- Pon el COM de la STM32
BAUDRATE = 115200         # <--- El de tu placa

print(f"Conectando al Brazo en {IP_ROBOT_ESCLAVO} y radar en {PUERTO_STM32}...")
arm = XArmAPI(IP_ROBOT_ESCLAVO)
sensor = serial.Serial(PUERTO_STM32, BAUDRATE, timeout=0) 

arm.clean_error()
arm.clean_warn()
time.sleep(0.5)

print("\n[Homing] Moviendo a la posición inicial (0º)...")
arm.motion_enable(enable=True)
arm.set_mode(0) 
arm.set_state(state=0)
time.sleep(0.5)
arm.set_servo_angle(angle=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], speed=30, mvacc=200, wait=True)

respuesta = input("\n¿Todo listo para empezar a seguir al Maestro? (Escribe 'si'): ")

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('0.0.0.0', PUERTO_UDP_RECIBO))
sock.settimeout(None)

arm.set_mode(0) 
arm.set_state(state=0)
time.sleep(0.5)

print("\n¡Seguimiento y Radar Háptico ACTIVADO!")
estado_choque = False
ip_maestro = None

# Memoria para el retroceso seguro
historial_seguro = [] 

try:
    while True:
        if arm.has_err_warn:
            arm.clean_error()
            arm.set_mode(0) 
            arm.set_state(state=0)
            time.sleep(0.2)
            continue

        # 1. RECIBIR MOVIMIENTOS DEL MAESTRO
        sock.settimeout(0.01) 
        try:
            data, addr = sock.recvfrom(1024)
            angles_recibidos = json.loads(data.decode())
            ip_maestro = addr[0] 
            
            if not estado_choque:
                # Guardar el historial de posiciones seguras (último medio segundo aprox)
                historial_seguro.append(angles_recibidos)
                if len(historial_seguro) > 10: 
                    historial_seguro.pop(0)
                
                # Movimiento más fluido (speed 100, mvacc 500)
                arm.set_servo_angle(angle=angles_recibidos, wait=False, speed=100, mvacc=500)
                # Print hacia abajo (sin el end='\r') para que no se trabe la terminal
                print(f"Copiando -> J1: {angles_recibidos[0]:.1f}º | J2: {angles_recibidos[1]:.1f}º")
        except socket.timeout:
            pass 

        # 2. LEER STM32 (1 = Choque, 0 = Libre)
        if sensor.in_waiting > 0:
            try:
                linea = sensor.readline().decode('utf-8').strip()
                
                if linea == "1" and not estado_choque:
                    estado_choque = True
                    print("\n[!] ALERTA: Obstáculo detectado. No se puede seguir en esa dirección.")
                    print("[!] Retrocediendo automáticamente para liberar el área...")
                    
                    if ip_maestro:
                        sock.sendto(b"CHOQUE", (ip_maestro, PUERTO_UDP_ENVIO))
                    
                    # El robot retrocede a la posición más antigua de su memoria
                    if len(historial_seguro) > 0:
                        posicion_segura = historial_seguro[0]
                        arm.set_servo_angle(angle=posicion_segura, wait=True, speed=150, mvacc=1000)
                        historial_seguro.clear() # Limpiamos memoria
                        
                elif linea == "0" and estado_choque: 
                    estado_choque = False
                    print(f"\n[✓] Libre de nuevo.")
                    if ip_maestro:
                        sock.sendto(b"LIBRE", (ip_maestro, PUERTO_UDP_ENVIO))
                            
            except ValueError:
                pass 

except KeyboardInterrupt:
    print("\n\nCierre de emergencia...")
    arm.set_mode(0)
    arm.set_state(state=0)
    arm.disconnect()
    sensor.close()
    sock.close()
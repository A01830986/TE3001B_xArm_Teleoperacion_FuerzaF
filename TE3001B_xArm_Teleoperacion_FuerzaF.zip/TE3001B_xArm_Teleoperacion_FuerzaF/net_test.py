# net_test.py

def mostrar_instrucciones_red():
    print("=========================================================")
    print("   HERRAMIENTA DE TEST DE RED (Validación de Latencia)   ")
    print("=========================================================")
    print("\nNota metodológica:")
    print("Para este proyecto, la medición de latencia (RTT) y la validación")
    print("de la conexión no se realizaron mediante un script de Python, sino")
    print("directamente utilizando las herramientas nativas del sistema operativo.")
    print("Esto proporciona una medición más pura y directa a nivel de red.\n")
    print("Procedimiento utilizado en el laboratorio:")
    print("  1. Abrir la consola de comandos (cmd) en Windows.")
    print("  2. Identificar la dirección IP del equipo remoto (PC Maestro/Esclavo).")
    print("  3. Ejecutar el comando: ping <direccion_ip>")
    print("  4. Verificar el tiempo de respuesta (RTT) y la estabilidad (jitter).\n")
    print("Los resultados de esta prueba se encuentran documentados con")
    print("capturas de pantalla en la Sección III-B del reporte (Fig. A2).")
    print("=========================================================\n")

if __name__ == "__main__":
    mostrar_instrucciones_red()
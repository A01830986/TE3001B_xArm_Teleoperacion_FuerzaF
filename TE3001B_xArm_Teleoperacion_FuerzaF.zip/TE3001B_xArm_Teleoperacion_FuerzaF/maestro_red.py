import time
import socket
import json
from xarm.wrapper import XArmAPI

# --- TUS IPs EXACTAS ---
IP_ROBOT_MAESTRO = '192.168.1.179'
IP_WIFI_ESCLAVO = '10.22.168.189'
PUERTO_UDP_ENVIO = 9000
PUERTO_UDP_RECIBO = 9001  # Nuevo puerto para escuchar el choque

print(f"Conectando al Brazo Maestro en {IP_ROBOT_MAESTRO}...")
arm = XArmAPI(IP_ROBOT_MAESTRO)

arm.clean_error()
arm.clean_warn()
time.sleep(0.5)

print("\n[Homing] Moviendo a la posición inicial (0º)...")
arm.motion_enable(enable=True)
arm.set_mode(0)
arm.set_state(state=0)
time.sleep(0.5)
arm.set_servo_angle(angle=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], speed=30, mvacc=200, wait=True)

print("\n[Manual] Liberando motores para control con la mano...")
arm.set_mode(2)
arm.set_state(state=0)
time.sleep(0.5)

# --- RED: CAÑÓN (Envío) y ANTENA (Recibo) ---
sock_envio = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

sock_recibo = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock_recibo.bind(('0.0.0.0', PUERTO_UDP_RECIBO))
sock_recibo.setblocking(False) # Súper importante: no traba el código si no hay alertas

modo_choque = False

print("\n=====================================================")
print("¡Teleoperación Bilateral Lista!")
print("Muévelo libremente. Si el esclavo choca, sentirás el tope.")
print("=====================================================\n")

try:
    while True:
        # 1. AUTO-RECUPERACIÓN
        if arm.has_err_warn:
            arm.clean_error()
            # Si estábamos chocando, lo mantenemos rígido (Modo 0), si no, suave (Modo 2)
            arm.set_mode(0 if modo_choque else 2)
            arm.set_state(state=0)
            time.sleep(0.2)
            continue

        # 2. ESCUCHAR ALERTAS DEL ESCLAVO (Feedback Háptico)
        try:
            data_fb, _ = sock_recibo.recvfrom(1024)
            estado = data_fb.decode()
            
            if estado == "CHOQUE" and not modo_choque:
                print("\n[!] ¡CHOQUE DETECTADO! Bloqueando Maestro...")
                arm.set_mode(0) # Pone el brazo rígido
                arm.set_state(state=0)
                modo_choque = True
            
            elif estado == "LIBRE" and modo_choque:
                print("\n[✓] Camino libre. Soltando Maestro...")
                arm.set_mode(2) # Lo vuelve a poner suave
                arm.set_state(state=0)
                modo_choque = False
                
        except BlockingIOError:
            pass # No llegó ningún paquete nuevo, seguimos normal

        # 3. ENVIAR MOVIMIENTOS AL ESCLAVO
        code, angles = arm.get_servo_angle()
        if code == 0 and angles is not None:
            mensaje = json.dumps(angles).encode()
            sock_envio.sendto(mensaje, (IP_WIFI_ESCLAVO, PUERTO_UDP_ENVIO))
            
            if not modo_choque:
                print(f"Transmitiendo -> J1: {angles[0]:.1f}º | J2: {angles[1]:.1f}º | J3: {angles[2]:.1f}º")
        
        time.sleep(0.05) 

except KeyboardInterrupt:
    print("\n\nCierre de emergencia...")
    arm.set_mode(0)
    arm.set_state(state=0)
    arm.disconnect()
    sock_envio.close()
    sock_recibo.close()